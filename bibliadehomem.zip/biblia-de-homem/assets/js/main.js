(function () {
  'use strict';

  // Mobile menu overlay
  var menu = document.getElementById('bdh-mobile-menu');
  var openBtn = document.getElementById('bdh-menu-open');
  var closeBtn = document.getElementById('bdh-menu-close');

  function setMenu(open) {
    if (!menu) return;
    menu.classList.toggle('is-open', open);
    document.body.classList.toggle('bdh-menu-open', open);
    if (openBtn) openBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
  }

  if (openBtn) openBtn.addEventListener('click', function () { setMenu(true); });
  if (closeBtn) closeBtn.addEventListener('click', function () { setMenu(false); });
  if (menu) {
    menu.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') setMenu(false);
    });
  }

  // "Como Fazer" expandable reflection box (single post)
  var cfToggle = document.getElementById('bdh-cf-toggle');
  var cfPanel = document.getElementById('bdh-cf-panel');

  if (cfToggle && cfPanel) {
    cfToggle.addEventListener('click', function () {
      var open = !cfPanel.classList.contains('is-open');
      cfPanel.classList.toggle('is-open', open);
      cfToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      cfToggle.querySelector('.label').textContent = open ? 'FECHAR' : 'COMO FAZER';
      cfToggle.querySelector('.arrow').textContent = open ? '↑' : '→';
    });
  }

  // Share button — native share sheet where available, clipboard fallback otherwise
  document.querySelectorAll('[data-bdh-share]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var shareData = { title: btn.getAttribute('data-title') || document.title, url: window.location.href };
      if (navigator.share) {
        navigator.share(shareData).catch(function () {});
      } else if (navigator.clipboard) {
        navigator.clipboard.writeText(shareData.url).then(function () {
          var original = btn.textContent;
          btn.textContent = 'LINK COPIADO';
          setTimeout(function () { btn.textContent = original; }, 1800);
        });
      }
    });
  });
})();
