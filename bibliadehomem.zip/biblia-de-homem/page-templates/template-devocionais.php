<?php
/**
 * Template Name: Devocionais
 * Template Post Type: page
 *
 * 365-day devotional listing: progress tracker, week calendar, filters, posts.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$progress = bdh_progress();
$week     = bdh_week_calendar();
$filtro   = isset( $_GET['filtro'] ) ? sanitize_key( $_GET['filtro'] ) : 'todos';
$paged    = isset( $_GET['pagina'] ) ? max( 1, absint( $_GET['pagina'] ) ) : 1;

$args = array(
	'category'       => bdh_devocionais_category_id(),
	'posts_per_page' => 8,
	'paged'          => $paged,
	'meta_key'       => '_bdh_dia',
	'orderby'        => 'meta_value_num',
	'order'          => 'DESC',
);

if ( 'semana' === $filtro ) {
	$args['date_query'] = array( array( 'after' => '1 week ago' ) );
} elseif ( 'mes' === $filtro ) {
	$args['date_query'] = array( array( 'after' => '1 month ago' ) );
}

$query = new WP_Query( $args );
$base_url = get_permalink();
?>

<main>

	<!-- HEADER -->
	<section class="bdh-hdr">
		<div class="bdh-hdr__bignum">02</div>
		<p class="bdh-hdr__kicker">Categoria 02</p>
		<h1>DEVOCIONAIS</h1>
		<p>365 reflexões para um ano inteiro de crescimento. Crie o seu devocional a partir do meu.</p>
	</section>

	<?php if ( $progress['day'] ) : ?>
	<!-- PROGRESS TRACKER -->
	<section class="progress-block">
		<div class="progress-top">
			<div>
				<span class="progress-day"><?php echo esc_html( $progress['day'] ); ?></span>
				<span class="progress-day-label">de <?php echo esc_html( $progress['total'] ); ?> dias</span>
			</div>
			<div>
				<div class="progress-streak-label">Sequência atual</div>
				<div class="progress-streak-value"><?php echo esc_html( $progress['streak'] ); ?> dias 🔥</div>
			</div>
		</div>
		<div class="progress-bar-track">
			<div class="progress-bar-fill" style="width:<?php echo esc_attr( $progress['percent'] ); ?>%"></div>
		</div>
		<div class="progress-note"><?php echo esc_html( $progress['percent'] ); ?>% concluído · <?php echo esc_html( $progress['remaining'] ); ?> dias restantes</div>
	</section>
	<?php endif; ?>

	<!-- WEEK CALENDAR -->
	<section class="week-block">
		<div class="week-label">Esta Semana</div>
		<div class="week-row">
			<?php foreach ( $week as $day ) :
				$cls = 'week-day';
				if ( $day['is_today'] ) {
					$cls .= ' week-day--today';
				} elseif ( $day['has_post'] ) {
					$cls .= ' week-day--done';
				}
			?>
			<div class="<?php echo esc_attr( $cls ); ?>">
				<div class="week-day__label"><?php echo esc_html( $day['label'] ); ?></div>
				<div class="week-day__circle"><span><?php echo esc_html( $day['number'] ); ?></span></div>
			</div>
			<?php endforeach; ?>
		</div>
	</section>

	<!-- FILTER TABS -->
	<nav class="filter-tabs" aria-label="<?php esc_attr_e( 'Filtrar devocionais', 'bdh' ); ?>">
		<a href="<?php echo esc_url( $base_url ); ?>" class="filter-tab<?php echo 'todos' === $filtro ? ' is-active' : ''; ?>">Todos</a>
		<a href="<?php echo esc_url( add_query_arg( 'filtro', 'semana', $base_url ) ); ?>" class="filter-tab<?php echo 'semana' === $filtro ? ' is-active' : ''; ?>">Esta semana</a>
		<a href="<?php echo esc_url( add_query_arg( 'filtro', 'mes', $base_url ) ); ?>" class="filter-tab<?php echo 'mes' === $filtro ? ' is-active' : ''; ?>">Este mês</a>
	</nav>

	<!-- POST LIST -->
	<?php if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post();
		$post_id = get_the_ID();
		$dia     = get_post_meta( $post_id, '_bdh_dia', true );
		$cover   = has_post_thumbnail() ? 'cover-img' : bdh_cover_class( $post_id );
		$cover_style = has_post_thumbnail() ? 'style="background-image:url(' . esc_url( get_the_post_thumbnail_url( $post_id, 'bdh-card' ) ) . ')"' : '';

		if ( 1 === $paged && 0 === $query->current_post ) : ?>
			<a href="<?php the_permalink(); ?>" class="post-hero">
				<div class="post-hero__cover <?php echo esc_attr( $cover ); ?>" <?php echo $cover_style; ?>>
					<div class="post-hero__badge">
						<span class="num"><?php echo esc_html( $dia ); ?></span>
						<span class="sep"></span>
						<span class="of">de <?php echo esc_html( BDH_TOTAL_DIAS ); ?></span>
					</div>
				</div>
				<div class="post-hero__body">
					<div class="post-hero__title"><?php the_title(); ?></div>
					<div class="post-hero__excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 24 ) ); ?></div>
					<div class="post-hero__meta">
						<span><?php echo esc_html( bdh_format_date_pt( get_the_date( 'U' ), true ) ); ?></span>
						<span class="dot"></span>
						<span><?php echo esc_html( bdh_reading_time( $post_id ) ); ?> min de leitura</span>
					</div>
				</div>
			</a>
		<?php else : ?>
			<a href="<?php the_permalink(); ?>" class="post-compact">
				<div class="post-compact__cover <?php echo esc_attr( $cover ); ?>" <?php echo $cover_style; ?>>
					<div class="post-compact__num"><span><?php echo esc_html( $dia ); ?></span></div>
				</div>
				<div class="post-compact__body">
					<div class="post-compact__cat">Devocionais</div>
					<div class="post-compact__title"><?php the_title(); ?></div>
					<div class="post-compact__meta"><?php echo esc_html( bdh_format_date_pt( get_the_date( 'U' ) ) ); ?> · <?php echo esc_html( bdh_reading_time( $post_id ) ); ?> min</div>
				</div>
			</a>
		<?php endif;
	endwhile; else : ?>
		<div class="section-white">
			<p><?php esc_html_e( 'Nenhum devocional publicado ainda. Crie um post, marque a categoria "Devocionais" e preencha o campo "Dia do devocional" para que apareça aqui.', 'bdh' ); ?></p>
		</div>
	<?php endif; ?>

	<!-- LOAD MORE -->
	<?php if ( $paged < $query->max_num_pages ) :
		$next_args = array( 'pagina' => $paged + 1 );
		if ( 'todos' !== $filtro ) {
			$next_args['filtro'] = $filtro;
		}
	?>
	<div class="loadmore-block">
		<a href="<?php echo esc_url( add_query_arg( $next_args, $base_url ) ); ?>" class="btn-ghost">CARREGAR MAIS</a>
	</div>
	<?php endif; ?>

	<?php wp_reset_postdata(); ?>

</main>

<?php get_footer(); ?>
