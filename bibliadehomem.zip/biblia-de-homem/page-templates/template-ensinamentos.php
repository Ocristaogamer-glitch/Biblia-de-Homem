<?php
/**
 * Template Name: Ensinamentos
 * Template Post Type: page
 *
 * Hub for the 4 roles (Marido, Pai, Filho, Sacerdote) + latest teachings.
 * Only Marido is wired to a working archive for now — the other 3 roles
 * render as preview cards, same as the prototype, and start working the
 * moment posts get tagged with that "papel" term (taxonomy-papel.php is generic).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$role_order = array( 'marido', 'pai', 'filho', 'sacerdote' );
$roles      = array();
foreach ( $role_order as $i => $slug ) {
	$term = get_term_by( 'slug', $slug, 'papel' );
	if ( ! $term ) {
		continue;
	}
	$children = get_terms( array(
		'taxonomy'   => 'papel',
		'parent'     => $term->term_id,
		'hide_empty' => false,
		'number'     => 3,
	) );
	$roles[] = array(
		'num'      => sprintf( '%02d', $i + 1 ),
		'term'     => $term,
		'children' => $children,
		'count'    => bdh_papel_post_count( $term->term_id ),
	);
}

$latest = get_posts( array(
	'category'       => bdh_ensinamentos_category_id(),
	'posts_per_page' => 3,
) );
?>

<main>

	<!-- HEADER -->
	<section class="bdh-hdr">
		<div class="bdh-hdr__bignum">03</div>
		<div class="bdh-hdr__rule"></div>
		<p class="bdh-hdr__kicker">Categoria 03</p>
		<h1>ENSINAMENTOS</h1>
		<p>Ensinamentos práticos para os quatro papéis de todo homem cristão.</p>
	</section>

	<!-- 4 ROLES GRID -->
	<section class="section-cream">
		<span class="eyebrow" style="display:block;margin-bottom:16px">Escolha seu papel</span>
		<div class="roles-grid">
			<?php foreach ( $roles as $role ) :
				$is_marido = 'marido' === $role['term']->slug;
				$tag       = $is_marido ? 'a' : 'div';
			?>
			<<?php echo $tag; ?> <?php echo $is_marido ? 'href="' . esc_url( get_term_link( $role['term'] ) ) . '"' : ''; ?> class="role-card <?php echo $is_marido ? 'role-card--featured' : 'role-card--plain'; ?>">
				<div class="role-card__letter"><?php echo esc_html( mb_substr( $role['term']->name, 0, 1 ) ); ?></div>
				<div class="role-card__num"><?php echo esc_html( $role['num'] ); ?></div>
				<div class="role-card__title"><?php echo esc_html( $role['term']->name ); ?></div>
				<?php if ( $role['children'] ) : ?>
				<div class="role-card__chips">
					<?php foreach ( $role['children'] as $child ) : ?>
						<div class="role-card__chip"><?php echo esc_html( $child->name ); ?></div>
					<?php endforeach; ?>
				</div>
				<?php endif; ?>
				<div class="role-card__count"><?php echo esc_html( $role['count'] ); ?> posts →</div>
			</<?php echo $tag; ?>>
			<?php endforeach; ?>
		</div>
	</section>

	<?php if ( $latest ) : ?>
	<!-- ÚLTIMOS ENSINAMENTOS -->
	<section class="section-white">
		<span class="eyebrow" style="display:block;margin-bottom:18px">Últimos Ensinamentos</span>
		<?php foreach ( $latest as $post ) :
			$papel_terms = get_the_terms( $post->ID, 'papel' );
			$papel_name  = $papel_terms && ! is_wp_error( $papel_terms ) ? $papel_terms[0]->name : '';
			$sub_name    = '';
			if ( $papel_terms ) {
				foreach ( $papel_terms as $t ) {
					if ( $t->parent ) {
						$sub_name = $t->name;
						break;
					}
				}
			}
			$cover = has_post_thumbnail( $post ) ? 'cover-img' : bdh_cover_class( $post->ID );
			$style = has_post_thumbnail( $post ) ? 'style="background-image:url(' . esc_url( get_the_post_thumbnail_url( $post, 'bdh-card' ) ) . ')"' : '';
		?>
		<a href="<?php echo esc_url( get_permalink( $post ) ); ?>" class="teaching-row">
			<div class="teaching-row__cover <?php echo esc_attr( $cover ); ?>" <?php echo $style; ?>></div>
			<div class="teaching-row__body">
				<div class="teaching-row__meta">
					<?php if ( $papel_name ) : ?><span class="teaching-row__role"><?php echo esc_html( $papel_name ); ?></span><?php endif; ?>
					<?php if ( $sub_name ) : ?><span class="teaching-row__sep"></span><span class="teaching-row__sub"><?php echo esc_html( $sub_name ); ?></span><?php endif; ?>
				</div>
				<div class="teaching-row__title"><?php echo esc_html( get_the_title( $post ) ); ?></div>
				<div class="teaching-row__date"><?php echo esc_html( bdh_format_date_pt( get_the_date( 'U', $post ) ) ); ?> · <?php echo esc_html( bdh_reading_time( $post->ID ) ); ?> min</div>
			</div>
		</a>
		<?php endforeach; ?>
	</section>
	<?php endif; ?>

</main>

<?php get_footer(); ?>
