<?php
/**
 * Post meta: devotional day number, YouTube video, the 3 personalized
 * reflection questions. Exposed through a single, simple meta box so adding
 * a new post stays fast (the chat's #1 pain point: "criar 1 post é cansativo").
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function bdh_register_post_meta() {
	$fields = array(
		'_bdh_dia'        => 'integer',
		'_bdh_youtube'    => 'string',
		'_bdh_pergunta_1' => 'string',
		'_bdh_pergunta_2' => 'string',
		'_bdh_pergunta_3' => 'string',
	);

	foreach ( $fields as $key => $type ) {
		register_post_meta( 'post', $key, array(
			'type'              => $type,
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => 'integer' === $type ? 'absint' : 'sanitize_text_field',
			'auth_callback'     => function () {
				return current_user_can( 'edit_posts' );
			},
		) );
	}
}
add_action( 'init', 'bdh_register_post_meta' );

function bdh_add_meta_box() {
	add_meta_box(
		'bdh_post_details',
		__( 'Bíblia de Homem — Detalhes do Post', 'bdh' ),
		'bdh_render_meta_box',
		'post',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'bdh_add_meta_box' );

function bdh_render_meta_box( $post ) {
	wp_nonce_field( 'bdh_save_meta', 'bdh_meta_nonce' );

	$dia        = get_post_meta( $post->ID, '_bdh_dia', true );
	$youtube    = get_post_meta( $post->ID, '_bdh_youtube', true );
	$pergunta_1 = get_post_meta( $post->ID, '_bdh_pergunta_1', true );
	$pergunta_2 = get_post_meta( $post->ID, '_bdh_pergunta_2', true );
	$pergunta_3 = get_post_meta( $post->ID, '_bdh_pergunta_3', true );
	?>
	<p>
		<label for="bdh_dia"><strong><?php esc_html_e( 'Dia do devocional (1–365)', 'bdh' ); ?></strong></label><br>
		<span class="description"><?php esc_html_e( 'Preencha só para posts na categoria Devocionais. Define o número exibido (ex: "Dia 167 de 365") e alimenta a barra de progresso e a sequência (streak) automaticamente.', 'bdh' ); ?></span><br>
		<input type="number" min="1" max="365" id="bdh_dia" name="bdh_dia" value="<?php echo esc_attr( $dia ); ?>" style="width:100px;margin-top:6px">
	</p>
	<p>
		<label for="bdh_youtube"><strong><?php esc_html_e( 'Link do vídeo do YouTube (opcional)', 'bdh' ); ?></strong></label><br>
		<input type="url" id="bdh_youtube" name="bdh_youtube" value="<?php echo esc_attr( $youtube ); ?>" style="width:100%;margin-top:6px" placeholder="https://www.youtube.com/watch?v=...">
	</p>
	<hr>
	<p><strong><?php esc_html_e( '"Faça o seu devocional" — 3 perguntas personalizadas', 'bdh' ); ?></strong><br>
	<span class="description"><?php esc_html_e( 'Aparecem no box expansível "Como Fazer" abaixo do post. Deixe em branco para usar as perguntas padrão.', 'bdh' ); ?></span></p>
	<p>
		<label for="bdh_pergunta_1"><?php esc_html_e( 'Pergunta 1', 'bdh' ); ?></label><br>
		<input type="text" id="bdh_pergunta_1" name="bdh_pergunta_1" value="<?php echo esc_attr( $pergunta_1 ); ?>" style="width:100%;margin-top:4px">
	</p>
	<p>
		<label for="bdh_pergunta_2"><?php esc_html_e( 'Pergunta 2', 'bdh' ); ?></label><br>
		<input type="text" id="bdh_pergunta_2" name="bdh_pergunta_2" value="<?php echo esc_attr( $pergunta_2 ); ?>" style="width:100%;margin-top:4px">
	</p>
	<p>
		<label for="bdh_pergunta_3"><?php esc_html_e( 'Pergunta 3', 'bdh' ); ?></label><br>
		<input type="text" id="bdh_pergunta_3" name="bdh_pergunta_3" value="<?php echo esc_attr( $pergunta_3 ); ?>" style="width:100%;margin-top:4px">
	</p>
	<?php
}

function bdh_save_meta_box( $post_id ) {
	if ( ! isset( $_POST['bdh_meta_nonce'] ) || ! wp_verify_nonce( $_POST['bdh_meta_nonce'], 'bdh_save_meta' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	if ( isset( $_POST['bdh_dia'] ) ) {
		$dia = absint( $_POST['bdh_dia'] );
		if ( $dia > 0 ) {
			update_post_meta( $post_id, '_bdh_dia', min( 365, $dia ) );
		} else {
			delete_post_meta( $post_id, '_bdh_dia' );
		}
	}

	if ( isset( $_POST['bdh_youtube'] ) ) {
		$url = esc_url_raw( trim( $_POST['bdh_youtube'] ) );
		if ( $url ) {
			update_post_meta( $post_id, '_bdh_youtube', $url );
		} else {
			delete_post_meta( $post_id, '_bdh_youtube' );
		}
	}

	foreach ( array( 'bdh_pergunta_1', 'bdh_pergunta_2', 'bdh_pergunta_3' ) as $field ) {
		if ( isset( $_POST[ $field ] ) ) {
			$value = sanitize_text_field( $_POST[ $field ] );
			if ( $value ) {
				update_post_meta( $post_id, '_' . $field, $value );
			} else {
				delete_post_meta( $post_id, '_' . $field );
			}
		}
	}
}
add_action( 'save_post', 'bdh_save_meta_box' );
