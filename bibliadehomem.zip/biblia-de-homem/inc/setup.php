<?php
/**
 * Theme support, asset loading, image sizes.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function bdh_theme_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'script', 'style' ) );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );

	// Cover images for posts: wide aspect, matches the gradient-cover cards in the design.
	add_image_size( 'bdh-card', 440, 260, true );
	add_image_size( 'bdh-cover', 1200, 700, true );

	register_nav_menus( array(
		'devocionais' => __( 'Página de Devocionais', 'bdh' ),
		'ensinamentos' => __( 'Página de Ensinamentos', 'bdh' ),
	) );
}
add_action( 'after_setup_theme', 'bdh_theme_setup' );

/**
 * Resolve the URL for the "Devocionais" and "Ensinamentos" hub pages.
 * Looks for a page using the matching template; falls back to the slug.
 */
function bdh_hub_url( $template_file, $fallback_slug ) {
	$pages = get_posts( array(
		'post_type'      => 'page',
		'meta_key'       => '_wp_page_template',
		'meta_value'     => $template_file,
		'posts_per_page' => 1,
		'fields'         => 'ids',
	) );

	if ( $pages ) {
		return get_permalink( $pages[0] );
	}

	$page = get_page_by_path( $fallback_slug );
	return $page ? get_permalink( $page ) : home_url( '/' . $fallback_slug . '/' );
}

function bdh_devocionais_url() {
	return bdh_hub_url( 'page-templates/template-devocionais.php', 'devocionais' );
}

function bdh_ensinamentos_url() {
	return bdh_hub_url( 'page-templates/template-ensinamentos.php', 'ensinamentos' );
}

function bdh_assets() {
	// Self-hosted-friendly preconnects; fonts are still pulled from Google Fonts as in the design.
	wp_enqueue_style(
		'bdh-fonts',
		'https://fonts.googleapis.com/css2?family=Bitter:ital,wght@0,700;0,900;1,400;1,700&family=Inter:wght@400;500;600&display=swap',
		array(),
		null
	);

	wp_enqueue_style( 'bdh-main', BDH_URI . '/assets/css/main.css', array( 'bdh-fonts' ), BDH_VERSION );

	wp_enqueue_script( 'bdh-main', BDH_URI . '/assets/js/main.js', array(), BDH_VERSION, true );
}
add_action( 'wp_enqueue_scripts', 'bdh_assets' );

/**
 * Lightweight Customizer controls: hero photo (optional — falls back to a
 * brand-color gradient, no broken image dependency) and social links.
 */
function bdh_customize_register( $wp_customize ) {
	$wp_customize->add_section( 'bdh_brand', array(
		'title'    => __( 'Bíblia de Homem', 'bdh' ),
		'priority' => 30,
	) );

	$wp_customize->add_setting( 'bdh_hero_image', array( 'sanitize_callback' => 'esc_url_raw' ) );
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'bdh_hero_image', array(
		'label'   => __( 'Imagem de fundo do hero (Home)', 'bdh' ),
		'section' => 'bdh_brand',
	) ) );

	foreach ( array(
		'bdh_linkedin_url'  => 'LinkedIn',
		'bdh_youtube_url'   => 'YouTube',
		'bdh_instagram_url' => 'Instagram',
	) as $setting => $label ) {
		$wp_customize->add_setting( $setting, array( 'sanitize_callback' => 'esc_url_raw' ) );
		$wp_customize->add_control( $setting, array(
			'label'   => $label,
			'section' => 'bdh_brand',
			'type'    => 'url',
		) );
	}
}
add_action( 'customize_register', 'bdh_customize_register' );

function bdh_resource_hints( $urls, $relation_type ) {
	if ( 'preconnect' === $relation_type ) {
		$urls[] = array( 'href' => 'https://fonts.googleapis.com' );
		$urls[] = array(
			'href'        => 'https://fonts.gstatic.com',
			'crossorigin' => true,
		);
	}
	return $urls;
}
add_filter( 'wp_resource_hints', 'bdh_resource_hints', 10, 2 );

/**
 * Disable emoji scripts/styles and other default-theme weight we don't need — Core Web Vitals.
 */
function bdh_trim_head() {
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_head', 'wp_generator' );
}
add_action( 'init', 'bdh_trim_head' );
