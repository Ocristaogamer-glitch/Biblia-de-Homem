<?php
/**
 * Template helpers: reading time, pt-BR dates, deterministic cover gradients,
 * and the Devocionais 365-day progress/streak/week-calendar computation.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const BDH_TOTAL_DIAS = 365;

function bdh_reading_time( $post_id ) {
	$content = get_post_field( 'post_content', $post_id );
	$words   = str_word_count( wp_strip_all_tags( strip_shortcodes( $content ) ) );
	return max( 1, (int) ceil( $words / 200 ) );
}

$GLOBALS['bdh_months_pt'] = array( 1 => 'Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez' );

function bdh_format_date_pt( $timestamp, $with_year = false ) {
	$months = $GLOBALS['bdh_months_pt'];
	$day    = date_i18n( 'j', $timestamp );
	$month  = $months[ (int) date_i18n( 'n', $timestamp ) ];
	$out    = "{$day} {$month}";
	if ( $with_year ) {
		$out .= ' ' . date_i18n( 'Y', $timestamp );
	}
	return $out;
}

/**
 * Deterministic cover gradient (1-6) so the same post always gets the same
 * placeholder color even without a featured image, matching the design's
 * palette-derived cover blocks.
 */
function bdh_cover_class( $post_id ) {
	return 'cover-' . ( ( $post_id % 6 ) + 1 );
}

function bdh_devocionais_category_id() {
	$term = get_term_by( 'name', 'Devocionais', 'category' );
	return $term ? (int) $term->term_id : 0;
}

function bdh_ensinamentos_category_id() {
	$term = get_term_by( 'name', 'Ensinamentos', 'category' );
	return $term ? (int) $term->term_id : 0;
}

function bdh_is_devocional( $post_id ) {
	return (bool) get_post_meta( $post_id, '_bdh_dia', true );
}

/**
 * Latest published devotional, used as "today's" entry across Home/Devocionais.
 */
function bdh_current_devocional() {
	static $post = null;
	if ( null !== $post ) {
		return $post;
	}

	$cat_id = bdh_devocionais_category_id();
	$posts  = get_posts( array(
		'category'       => $cat_id,
		'posts_per_page' => 1,
		'meta_key'       => '_bdh_dia',
		'orderby'        => 'meta_value_num',
		'order'          => 'DESC',
	) );

	$post = $posts ? $posts[0] : false;
	return $post;
}

function bdh_progress() {
	$current = bdh_current_devocional();
	$day     = $current ? (int) get_post_meta( $current->ID, '_bdh_dia', true ) : 0;
	$percent = $day ? round( ( $day / BDH_TOTAL_DIAS ) * 100, 1 ) : 0;

	return array(
		'day'        => $day,
		'total'      => BDH_TOTAL_DIAS,
		'percent'    => $percent,
		'remaining'  => max( 0, BDH_TOTAL_DIAS - $day ),
		'streak'     => bdh_streak(),
	);
}

/**
 * Consecutive calendar days (ending on the most recent devotional's date)
 * that have a published Devocionais post — a real publishing streak.
 */
function bdh_streak() {
	$cat_id = bdh_devocionais_category_id();
	$posts  = get_posts( array(
		'category'       => $cat_id,
		'posts_per_page' => 400,
		'orderby'        => 'date',
		'order'          => 'DESC',
		'fields'         => 'ids',
	) );

	if ( ! $posts ) {
		return 0;
	}

	$dates = array();
	foreach ( $posts as $post_id ) {
		$dates[ get_the_date( 'Y-m-d', $post_id ) ] = true;
	}
	$dates = array_keys( $dates );
	rsort( $dates );

	$streak  = 1;
	$cursor  = strtotime( $dates[0] );
	for ( $i = 1; $i < count( $dates ); $i++ ) {
		$expected = strtotime( '-1 day', $cursor );
		if ( strtotime( $dates[ $i ] ) === $expected ) {
			$streak++;
			$cursor = $expected;
		} else {
			break;
		}
	}

	return $streak;
}

/**
 * Mon–Sun of the current real week, each day flagged with whether a
 * Devocionais post was published that day.
 */
function bdh_week_calendar() {
	$cat_id    = bdh_devocionais_category_id();
	$today_ts  = current_time( 'timestamp' );
	$monday_ts = strtotime( 'monday this week', $today_ts );
	$labels    = array( 'SEG', 'TER', 'QUA', 'QUI', 'SEX', 'SAB', 'DOM' );

	$posts = get_posts( array(
		'category'       => $cat_id,
		'posts_per_page' => 7,
		'date_query'     => array(
			array(
				'after'     => date( 'Y-m-d', $monday_ts ),
				'before'    => date( 'Y-m-d', strtotime( '+6 days', $monday_ts ) ) . ' 23:59:59',
				'inclusive' => true,
			),
		),
		'fields' => 'ids',
	) );

	$posted_dates = array();
	foreach ( $posts as $post_id ) {
		$posted_dates[ get_the_date( 'Y-m-d', $post_id ) ] = true;
	}

	$days  = array();
	$today = date( 'Y-m-d', $today_ts );

	for ( $i = 0; $i < 7; $i++ ) {
		$ts   = strtotime( "+{$i} day", $monday_ts );
		$ymd  = date( 'Y-m-d', $ts );
		$days[] = array(
			'label'    => $labels[ $i ],
			'number'   => date( 'j', $ts ),
			'is_today' => $ymd === $today,
			'has_post' => isset( $posted_dates[ $ymd ] ),
			'is_past'  => $ts < strtotime( $today ),
		);
	}

	return $days;
}

function bdh_youtube_embed_url( $url ) {
	if ( ! $url ) {
		return '';
	}
	$id = '';
	if ( preg_match( '~(?:youtu\.be/|youtube\.com/(?:watch\?v=|embed/|shorts/))([A-Za-z0-9_-]{6,})~', $url, $m ) ) {
		$id = $m[1];
	}
	return $id ? 'https://www.youtube-nocookie.com/embed/' . $id : '';
}

function bdh_papel_url( $slug ) {
	$term = get_term_by( 'slug', $slug, 'papel' );
	return $term ? get_term_link( $term ) : '#';
}

function bdh_papel_post_count( $term_id ) {
	$term = get_term( $term_id, 'papel' );
	return $term ? (int) $term->count : 0;
}

/**
 * Which bottom-tab / nav item is "active" for the current request.
 */
function bdh_active_tab() {
	if ( is_front_page() ) {
		return 'home';
	}
	if ( is_page_template( 'page-templates/template-devocionais.php' ) ) {
		return 'devocionais';
	}
	if ( is_page_template( 'page-templates/template-ensinamentos.php' ) || is_tax( 'papel' ) ) {
		return 'ensinamentos';
	}
	if ( is_singular( 'post' ) ) {
		return bdh_is_devocional( get_the_ID() ) ? 'devocionais' : 'ensinamentos';
	}
	return '';
}

/**
 * The brand icon — open book with an anchor (Hebrews 6:19), bold outline.
 * Matches the final SVG approved in the design chat.
 */
function bdh_icon_svg( $size = 28, $stroke = '#F4EFE6', $opacity = 1 ) {
	return sprintf(
		'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="%1$d" height="%1$d" fill="none" stroke="%2$s" stroke-width="5.5" stroke-linecap="round" stroke-linejoin="round" style="opacity:%3$s" aria-hidden="true" focusable="false">
			<path d="M8 84 L8 20 Q8 6 22 6 L48 6 L48 88 Q32 82 12 88 Z"></path>
			<path d="M92 84 L92 20 Q92 6 78 6 L52 6 L52 88 Q68 82 88 88 Z"></path>
			<circle cx="50" cy="27" r="6.5"></circle>
			<line x1="34" y1="38" x2="66" y2="38"></line>
			<line x1="50" y1="33" x2="50" y2="72"></line>
			<path d="M34 65 Q34 79 50 75 Q66 79 66 65"></path>
			<line x1="34" y1="65" x2="25" y2="56"></line>
			<line x1="66" y1="65" x2="75" y2="56"></line>
		</svg>',
		(int) $size,
		esc_attr( $stroke ),
		esc_attr( $opacity )
	);
}
