<?php
/**
 * "Papel" taxonomy — the 4 roles (Marido, Pai, Filho, Sacerdote) used by the
 * Ensinamentos section, each with sub-category child terms.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function bdh_register_taxonomies() {
	register_taxonomy( 'papel', array( 'post' ), array(
		'hierarchical'      => true,
		'public'            => true,
		'show_admin_column' => true,
		'show_in_rest'      => true,
		'rewrite'           => array( 'slug' => 'papel' ),
		'labels'            => array(
			'name'          => __( 'Papéis (Ensinamentos)', 'bdh' ),
			'singular_name' => __( 'Papel', 'bdh' ),
			'menu_name'     => __( 'Papéis', 'bdh' ),
		),
	) );
}
add_action( 'init', 'bdh_register_taxonomies' );

/**
 * Seed the categories and "papel" terms described in the visual identity guide
 * so the Ensinamentos hub and Devocionais section work out of the box.
 * Safe to run repeatedly — wp_insert_term() / wp_insert_category() no-op on existing terms.
 */
function bdh_seed_taxonomy_terms() {
	if ( get_option( 'bdh_terms_seeded' ) ) {
		return;
	}

	foreach ( array( 'Devocionais', 'Ensinamentos', 'Comece Aqui' ) as $cat ) {
		if ( ! term_exists( $cat, 'category' ) ) {
			wp_insert_term( $cat, 'category' );
		}
	}

	$roles = array(
		'marido'    => array( 'Marido', array( 'Fidelidade', 'Um Casal Feliz', 'A Mulher Delicada', 'Liderança', 'Comunicação' ) ),
		'pai'       => array( 'Pai', array( 'Educar com Amor', 'Presença de Pai', 'Disciplina Bíblica' ) ),
		'filho'     => array( 'Filho', array( 'Honrar os Pais', 'Gratidão' ) ),
		'sacerdote' => array( 'Sacerdote', array( 'Culto em Casa', 'Intercessão', 'Liderança Espiritual' ) ),
	);

	foreach ( $roles as $slug => $data ) {
		list( $name, $children ) = $data;

		if ( ! term_exists( $slug, 'papel' ) ) {
			wp_insert_term( $name, 'papel', array( 'slug' => $slug ) );
		}
		$parent = get_term_by( 'slug', $slug, 'papel' );
		if ( ! $parent ) {
			continue;
		}

		foreach ( $children as $child_name ) {
			$child_slug = $slug . '-' . sanitize_title( $child_name );
			if ( ! term_exists( $child_slug, 'papel' ) ) {
				wp_insert_term( $child_name, 'papel', array(
					'slug'   => $child_slug,
					'parent' => $parent->term_id,
				) );
			}
		}
	}

	update_option( 'bdh_terms_seeded', 1 );
}
add_action( 'init', 'bdh_seed_taxonomy_terms', 20 );
